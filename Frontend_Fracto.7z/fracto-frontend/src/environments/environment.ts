export const environment = {
  production: false,
  apiUrl: 'http://localhost:5002/api'
};
